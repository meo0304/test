CREATE DATABASE my_store ;
 USE my_store;
CREATE TABLE category (id INT AUTO_INCREMENT PRIMARY KEY , name VARCHAR (100) NOT NULL ,
 description  TEXT );

CREATE  TABLE product (
	id INT AUTO_INCREMENT PRIMARY KEY ,
	name VARCHAR (100) NOT NULL,
	description TEXT ,
	price DECIMAL (10 , 2) NOT NULL ,
	image VARCHAR (255) DEFAULT NULL ,
	category_id INT ,
	FOREIGN KEY (category_id ) REFERENCES category(id)


);

CREATE TABLE orders (
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(255) NOT NULL,
phone VARCHAR(20) NOT NULL,
address TEXT NOT NULL,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE order_details (
id INT AUTO_INCREMENT PRIMARY KEY,
order_id INT NOT NULL,
product_id INT NOT NULL,
quantity INT NOT NULL,
price DECIMAL(10, 2) NOT NULL,
FOREIGN KEY (order_id) REFERENCES orders(id)
);

 CREATE TABLE account (
id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(255) NOT NULL UNIQUE,
fullname VARCHAR(255) NOT NULL,
password VARCHAR(255) NOT NULL,
role ENUM('admin', 'user') DEFAULT 'user'
);


INSERT INTO category (name , description)
VALUES ('Laptop' , 'Thiết bị điện tử '),
('Điện thoại ','Thiết bị di dộng'),
('Phụ kiện ' , 'Phụ kiện di dộng'),
('Tablet', 'Máy tính bảng'),
('Tai nghe', 'Thiết bị âm thanh');



-- Thêm hơn 12 sản phẩm
INSERT INTO product (name, description, price, image, category_id) VALUES
-- Laptop (category_id = 1)
('Laptop Dell XPS 13', 'Laptop cao cấp, i7-12700H, 16GB RAM, 512GB SSD', 25990000, 'uploads/dell_xps13.jpg', 1),
('Laptop MacBook Pro 14', 'M2 Pro, 16GB RAM, 1TB SSD', 49990000, 'uploads/macbook_pro14.jpg', 1),
('Laptop Asus ROG Zephyrus', 'Gaming laptop, RTX 3060, 16GB RAM', 32990000, 'uploads/asus_rog.jpg', 1),
('Laptop Lenovo ThinkPad X1', 'Business laptop, i5-1240P, 16GB RAM', 27990000, 'uploads/thinkpad_x1.jpg', 1),

-- Điện thoại (category_id = 2)
('iPhone 14 Pro Max', '256GB, A16 Bionic', 33990000, 'uploads/iphone_14pro.jpg', 2),
('Samsung Galaxy S23 Ultra', '512GB, Snapdragon 8 Gen 2', 31990000, 'uploads/samsung_s23.jpg', 2),
('Xiaomi 13 Pro', '256GB, Snapdragon 8 Gen 2', 22990000, 'uploads/xiaomi_13pro.jpg', 2),
('Oppo Find X5 Pro', '256GB, Dimensity 9000', 19990000, 'uploads/oppo_findx5.jpg', 2),

-- Phụ kiện (category_id = 3)
('Sạc nhanh 65W', 'Bộ sạc nhanh USB-C', 590000, 'uploads/charger_65w.jpg', 3),
('Cáp USB-C', 'Cáp sạc dài 2m, 100W', 250000, 'uploads/usb_c_cable.jpg', 3),
('Ốp lưng iPhone 14', 'Ốp silicone chính hãng', 390000, 'uploads/iphone_case.jpg', 3),

-- Tablet (category_id = 4)
('iPad Pro 12.9', 'M2, 256GB', 29990000, 'uploads/ipad_pro.jpg', 4),
('Samsung Galaxy Tab S8', 'Snapdragon 8 Gen 1, 128GB', 18990000, 'uploads/galaxy_tab_s8.jpg', 4),

-- Tai nghe (category_id = 5)
('AirPods Pro 2', 'Tai nghe không dây Apple', 6490000, 'uploads/airpods_pro2.jpg', 5),
('Sony WH-1000XM5', 'Tai nghe over-ear chống ồn', 8490000, 'uploads/sony_xm5.jpg', 5),
('JBL Tune 130NC', 'Tai nghe true wireless', 1990000, 'uploads/jbl_tune.jpg', 5);