<?php
class CategoryModel
{
private $conn;
private $table_name = "category";

//30 BÀI 2TẠO CƠ SỞ DỮ LIỆU CHO WEBSITE BÁN HÀNG, XÂY DỰNG CHỨC NĂNG HIỂN THỊ/ THÊM/ XÓA/ SỬA

public function __construct($db)
{
$this->conn = $db;
}
public function getCategories()
{
$query = "SELECT id, name, description FROM " . $this->table_name;
$stmt = $this->conn->prepare($query);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_OBJ);
return $result;
}
}
?>