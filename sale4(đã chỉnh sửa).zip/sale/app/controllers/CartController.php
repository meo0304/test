<?php
class CartController {
    public function view() {
        // Logic lấy dữ liệu giỏ hàng (tạm thời để trống hoặc thêm logic sau)
        $cartItems = []; // Ví dụ: mảng rỗng để test
        
        // Load view
        require_once 'app/views/view.php';
    }
}