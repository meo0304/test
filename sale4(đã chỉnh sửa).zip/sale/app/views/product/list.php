<?php include 'app/views/shares/header.php'; ?>
<div class="container my-5">
    <h1 class="text-center mb-4">Danh sách sản phẩm</h1>
    <?php if (SessionHelper::isAdmin()): ?>
        <div class="text-end mb-3">
            <a href="/Product/add" class="btn btn-success"><i class="fas fa-plus me-1"></i> Thêm sản phẩm mới</a>
        </div>
    <?php endif; ?>

    <!-- Phần Giá Sốc (Carousel) -->
    <div id="promoCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
        <!-- Carousel Indicators -->
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#promoCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#promoCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#promoCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>

        <div class="carousel-inner">
            <!-- Banner 1 -->
            <div class="carousel-item active">
                <div class="promo-banner" style="background: linear-gradient(135deg, #ff6f61, #ff9f80); border-radius: 15px; padding: 30px; color: white; position: relative; min-height: 400px; background-image: url('/images/promo-bg-pattern.png'); background-size: cover; background-position: center;">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center">
                            <img src="/uploads/desk_header_20_73e6621375.jpg" alt="iPhone 16 Pro Max" style="max-width: 1300px;">
                        </div>
                        <div class="col-md-6 text-end">

                           </div>
                    </div>
                </div>
            </div>
            <!-- Banner 2 -->
            <div class="carousel-item">
                <div class="promo-banner" style="background: linear-gradient(135deg, #ff6f61, #ff9f80); border-radius: 15px; padding: 30px; color: white; position: relative; min-height: 400px; background-image: url('/images/promo-bg-pattern.png'); background-size: cover; background-position: center;">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center">
                            <img src="/uploads/desk_header_ebb29a244f.png" alt="Galaxy S25 Ultra" style="max-width: 1300px;">
                        </div>
                        <div class="col-md-6 text-end">

                            </div>
                    </div>
                </div>
            </div>
            <!-- Banner 3 -->
            
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#promoCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#promoCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Danh sách sản phẩm -->
    <div class="row">
        <?php foreach ($products as $product): ?>
            <div class="col-md-3 mb-4">
                <div class="card product-card h-100 shadow-sm">
                    <?php if ($product->image): ?>
                        <img src="/<?php echo htmlspecialchars($product->image, ENT_QUOTES, 'UTF-8'); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?>" style="height: 200px; object-fit: cover;">
                    <?php else: ?>
                        <img src="/images/no-image.png" class="card-img-top" alt="No Image" style="height: 200px; object-fit: cover;">
                    <?php endif; ?>
                    <div class="card-body text-center">
                        <h5 class="card-title">
                            <a href="/Product/show/<?php echo $product->id; ?>" class="text-dark text-decoration-none"><?php echo htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?></a>
                        </h5>
                        <p class="text-danger fw-bold"><?php echo number_format($product->price, 0, ',', '.'); ?> VNĐ</p>
                        <p class="text-muted"><?php echo htmlspecialchars($product->category_name, ENT_QUOTES, 'UTF-8'); ?></p>
                        <div class="d-flex gap-2 justify-content-center">
                            <a href="/Product/addToCart/<?php echo $product->id; ?>" class="btn btn-primary btn-sm"><i class="fas fa-cart-plus me-1"></i> Thêm vào giỏ</a>
                            <?php if (SessionHelper::isAdmin()): ?>
                                <a href="/Product/edit/<?php echo $product->id; ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit me-1"></i> Sửa</a>
                                <a href="/Product/delete/<?php echo $product->id; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');"><i class="fas fa-trash me-1"></i> Xóa</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php include 'app/views/shares/footer.php'; ?>

<style>
    .product-card {
        transition: all 0.3s;
    }
    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    .card-title a:hover {
        color: #007bff;
    }

    /* CSS cho phần Giá Sốc */
    .promo-banner {
        min-height: 400px;
        transition: all 0.3s;
    }
    .promo-banner:hover {
        transform: scale(1.02);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    .promo-banner img {
        max-width: 300px;
    }
    .promo-banner h3 {
        font-weight: bold;
    }
    .promo-banner p {
        margin: 0;
    }
    .carousel-indicators [data-bs-target] {
        background-color: #fff;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        margin: 0 5px;
    }
    .carousel-indicators .active {
        background-color: #ff6f61;
    }
    .carousel-control-prev, .carousel-control-next {
        width: 5%;
    }
    .carousel-control-prev-icon, .carousel-control-next-icon {
        background-color: rgba(0, 0, 0, 0.5);
        border-radius: 50%;
        width: 40px;
        height: 40px;
    }
</style>